nombre_completo = input("¿Cuál es tu nombre completo? ")

print("Nombre en minúsculas:", nombre_completo.lower())
print("Nombre en mayúsculas:", nombre_completo.upper())
print("Nombre con primera letra en mayúscula:", nombre_completo.title())