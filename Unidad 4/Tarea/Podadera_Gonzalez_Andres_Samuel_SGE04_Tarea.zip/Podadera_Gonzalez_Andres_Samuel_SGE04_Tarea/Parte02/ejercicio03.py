nombre=input("¿Cuál es tu nombre? ")
print(f"¡Hola {nombre}!")