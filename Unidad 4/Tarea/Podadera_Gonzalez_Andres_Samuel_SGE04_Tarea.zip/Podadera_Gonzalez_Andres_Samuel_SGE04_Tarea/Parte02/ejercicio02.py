mensaje="¡Hola Mundo!"
print(mensaje)