pwd= input('Introduce la contraseña: ') # sustituimos " por '
if pwd in ['curso2324']: # cambiamos ) por ]
    print('Inicio de sesión realizado')
else: # añadimos los :
    print('Error en inicio de sesión')