def saludar(mensaje='¡Hola amiga!'):
    print(mensaje)
    
saludar()
saludar('¡Hola amiga!')