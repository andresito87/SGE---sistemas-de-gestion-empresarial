print('¡Hola Mundo!')
